using CsvHelper;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Galytix.WebApi.Controllers
{
    [ApiController]
    [Route("/api/[controller]")]
    public class CountryGwpController : ControllerBase
    {
        private readonly Dictionary<string, Dictionary<string, decimal>> _data;

        public CountryGwpController()
        {
            _data = LoadDataFromCsv();
        }

        [HttpPost]
        [Route("avg")]
        public IActionResult CalculateAverage([FromBody] CountryGwpRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.Country) || request.Lob == null || !request.Lob.Any())
            {
                return BadRequest("Invalid request");
            }

            var result = new Dictionary<string, decimal>();

            foreach (var lob in request.Lob)
            {
                if (_data.TryGetValue(request.Country, out var countryData) && countryData.ContainsKey(lob))
                {
                    result.Add(lob, countryData[lob]);
                }
                else
                {
                    result.Add(lob, 0.0M); // or handle missing data accordingly
                }
            }

            return Ok(result);
        }

        private Dictionary<string, Dictionary<string, decimal>> LoadDataFromCsv()
        {
            var data = new Dictionary<string, Dictionary<string, decimal>>();

            // Assuming your CSV file is named 'gwpByCountry.csv' and is located in the 'Data' folder
            var csvFilePath = Path.Combine("Data", "gwpByCountry.csv");

            using (var reader = new StreamReader(csvFilePath))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = csv.GetRecords<dynamic>().ToList();

                foreach (var record in records)
                {
                    var country = record.CountryCode;
                    var lineOfBusiness = record.LineOfBusiness;
                    var value = decimal.Parse(record.Value);

                    if (!data.ContainsKey(country))
                    {
                        data[country] = new Dictionary<string, decimal>();
                    }

                    if (!data[country].ContainsKey(lineOfBusiness))
                    {
                        data[country][lineOfBusiness] = 0.0M;
                    }

                    data[country][lineOfBusiness] += value;
                }
            }

            return data;
        }
    }
}
